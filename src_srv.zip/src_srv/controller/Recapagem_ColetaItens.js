const Recapagem_ColetaItens =require('../models/Recapagem_ColetaItens.js')

module.exports = {

    async store (req,res){
        const dados =req.body
        console.log('dentro')
        const retorno = await Recapagem_ColetaItens.bulkCreate(dados, {returning: true})
        
        .then(function(item){
            res.status(200).json( item);
          }).catch(function (err) {
            res.status(400).send(err)
          });
    },

    async index (req,res){
        const retorno = await Recapagem_ColetaItens.findAll()
        .then(function(item){
            res.status(200).json( item);
          }).catch(function (err) {
            res.status(400).send(err)
          });
    }
}