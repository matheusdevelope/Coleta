const Recapagem_Coletas = require('../models/Recapagem_Coletas.js')
const Sequelize = require('sequelize')
module.exports = {

  async store(req, res) {
    const dados = req.body
    const retorno = await Recapagem_Coletas.bulkCreate(dados, { returning: true })
      .then(function (item) {
        res.status(200).json(item);
      }).catch(function (err) {
        res.status(400).send(err)
      });
  },

  async index(req, res) {
    const retorno = await Recapagem_Coletas.findAll()
      .then(function (item) {
        res.status(200).json(item);
      }).catch(function (err) {
        res.status(400).send(err)
      });
  },
  async indexByCod_Importacao(req, res) {
    const { Cod_Importacao } = req.params
    const Coletas = await Recapagem_Coletas.findAll({
      where: {
        Cod_Importacao: Cod_Importacao
      }
    });
    return res.json(Coletas);
    /*return res.json(client.services);   in this waY RETURNS JUST THE SERVICES */
  },
   CancelColetas(req, res) {
    const array = req.body
    array.map(async(item) =>{
      const Coletas = await Recapagem_Coletas.update(
        {
          ImportaColeta: 'CANCELADO',
          Status: item.Status,
          CodCancelamento: item.CodCancelamento,
          ObservacaoCancelamento: item.ObservacaoCancelamento,
          DataCancelamento: item.DataCancelamento,
          HoraCancelamento: item.HoraCancelamento,
          UsuarioCancelamento: item.UsuarioCancelamento,
          EstacaoCancelamento: item.EstacaoCancelamento,// the field you want to update
        },
        {
          where: { IdMobile:  item.IdMobile },
        },
      )
        .then(async function (item) {
          let Cod_Importacao = 0
          let retorno = "Erro ao sincronizar dados"
          Cod_Importacao = array[0].Cod_Importacao
          const Coletas = await Recapagem_Coletas.findAll({
            where: {
              Cod_Importacao: Cod_Importacao
            }
          })
              .then(function (item) {
                retorno = item
              }).catch(function (err) {
                retorno = err
              })
          res.status(200).json(retorno);
        }).catch(function (err) {
          res.status(400).send(err)
        });
      //  return res.json(Coletas)
    })
    
  },
}
