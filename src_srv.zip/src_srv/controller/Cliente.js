const Cliente =require('../models/Cliente.js')

module.exports = {
  async store(req, res) {
    const dados = req.body
    const retorno = await Cliente.bulkCreate(dados, { returning: true })
      .then(function (item) {
        res.status(200).json(item);
      }).catch(function (err) {
        res.status(400).send(err)
      });
  },
    async index (req,res){
        const retorno = await Cliente.findAll(
            { attributes: ['CodCliente', 'Nome', 'NomeFantasia', 'Telefone', 'Celular', 'CNPJ_CPF']}
        )
        .then(function(item){
            res.status(200).json( item);
          }).catch(function (err) {
            res.status(400).send(err)
          });
    }
}