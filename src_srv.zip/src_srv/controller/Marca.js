const Marca =require('../models/Marca.js')

module.exports = {
  async store(req, res) {
    const dados = req.body
    const retorno = await Marca.bulkCreate(dados, { returning: true })
      .then(function (item) {
        res.status(200).json(item);
      }).catch(function (err) {
        res.status(400).send(err)
      });
  },
    async index (req,res){
        const retorno = await Marca.findAll(
            { attributes: ['CodMarca', 'Nome']}
        ) .then(function(item){
            res.status(200).json( item);
          }).catch(function (err) {
            res.status(400).send(err)
          });
    }
}