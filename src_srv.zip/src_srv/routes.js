const express = require('express')
const Recapagem_Coletas = require('./controller/Recapagem_Coletas')
const Recapagem_ColetaItens = require('./controller/Recapagem_ColetaItens')
const Cliente = require('./controller/Cliente')
const Marca = require('./controller/Marca')
const routes = express.Router()


routes.post('/Coletas', Recapagem_Coletas.store )
routes.get('/Coletas', Recapagem_Coletas.index)
routes.get('/Coletas/:Cod_Importacao', Recapagem_Coletas.indexByCod_Importacao)
routes.put('/Coletas', Recapagem_Coletas.CancelColetas)


routes.post('/ItensColetas', Recapagem_ColetaItens.store )
routes.get('/ItensColetas', Recapagem_ColetaItens.index)

routes.get('/Clientes', Cliente.index)
routes.post('Clientes', Cliente.store)
routes.get('/Marcas', Marca.index)
routes.post('Marcas', Marca.store)

routes.get('/', (req, res) => {
    res.send({ express: 'YOUR EXPRESS BACKEND IS CONNECTED TO REACT' }); 
  }); 
module.exports = routes

