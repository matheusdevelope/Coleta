const Sequelize = require('sequelize')
const dbConfig = require ('../config/database')

const Recapagem_Coletas = require('../models/Recapagem_Coletas')
const Recapagem_ColetaItens = require('../models/Recapagem_ColetaItens')
const Cliente = require ('../models/Cliente')
const Marca = require ('../models/Marca')

const connection = new Sequelize (dbConfig)

Recapagem_Coletas.init(connection)
Recapagem_ColetaItens.init(connection)
Cliente.init(connection)
Marca.init(connection)
module.exports = connection


/** 
Client.associate(connection.models)
Service.associate(connection.models)
 */