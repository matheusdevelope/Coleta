'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Recapagem_Coletas', {
      id: {
        allowNull: false,
        autoIncrement: true,
        type: Sequelize.INTEGER
      },
      Cod_Importacao: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      CodEmpresa: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      CodFilial: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      CodVendedorIndex: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      Item: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      CodColeta: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      NumeroPedido: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      NumeroDocumento: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      NumeroColeta: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      Status: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      CodPrioridade: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      DataLancamento: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      HoraLancamento: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      UsuarioLancamento: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      EstacaoLancamentos: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      DataEmissao: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      DataColeta: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      DataPrevistaEntrega: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      CodVendedor: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      CodColetador: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      CodTecnico: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      CodCliente: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      NomeCliente: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      CodCancelamento: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      ObservacaoCancelamento: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      DataCancelamento: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      HoraCancelamento: {
        type: Sequelize.TIME,
        allowNull: true,
      },
      UsuarioCancelamento: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      EstacaoCancelamento: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      Garantia: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      ImportaColeta: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      ItemColeta: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      IdMobile:{
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    })
    .then(() => {
      return queryInterface.sequelize.query('ALTER TABLE "Recapagem_Coletas" ADD CONSTRAINT "ID_Importacao_Vendedor" PRIMARY KEY ( "Cod_Importacao", "CodEmpresa", "CodFilial", "Item", "CodVendedorIndex")');
    })
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Recapagem_Coletas');
  }
};