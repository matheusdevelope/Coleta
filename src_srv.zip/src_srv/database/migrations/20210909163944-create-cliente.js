'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Cliente', {
      CodCliente: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      Nome: {
        allowNull: false,
        type: Sequelize.STRING
      },
      NomeFantasia: {
        allowNull: false,
        type: Sequelize.STRING
      },
      CNPJ_CPF: {
        allowNull: false,
        type: Sequelize.STRING
      },
      Celular: {
        type: Sequelize.STRING
      },
      Telefone: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Cliente');
  }
};