'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Recapagem_ColetaItens', {
      id: {
        allowNull: false,
        autoIncrement: true,
        type: Sequelize.INTEGER
      },
      Cod_Importacao: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      CodEmpresa: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      CodFilial: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      CodVendedorIndex: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      Item: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      CodColeta: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      CodProduto: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      NomeProduto: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      NumeroSerie: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      CodMarca: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      Marca: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      Modelo: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      Dimensao: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      Desenho: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      NumeroFogo: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      NumeroDot: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      CodSituacao: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      CodTipo: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      Placa: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      ServicosExecutar: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      ExameInicial: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      Observacao: {
        type: Sequelize.STRING,
        allowNull: true,
      },
      Valor: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
      },
      IdMobile:{
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      ImportaColeta: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    })
      .then(() => {
        return queryInterface.sequelize.query('ALTER TABLE "Recapagem_ColetaItens" ADD CONSTRAINT "ID_Importacao_Itens_Coleta" PRIMARY KEY ( "Cod_Importacao", "CodEmpresa", "CodFilial", "Item", "CodVendedorIndex")');
      })
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Recapagem_ColetaItens');
  }
};