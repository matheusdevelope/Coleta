const { Model, DataTypes } = require('sequelize');

class Cliente extends Model {
  static init(sequelize) {
    super.init({
    CodCliente: DataTypes.INTEGER,
    Nome: DataTypes.STRING,
    NomeFantasia: DataTypes.STRING,
    CNPJ_CPF: DataTypes.STRING,
    Celular:DataTypes.STRING,
    Telefone: DataTypes.STRING
    }, {
      sequelize,
        freezeTableName: true
    })
  }
  static associate(models) { }
}

module.exports = Cliente;

