const { Model, DataTypes } = require('sequelize');

class Marca extends Model {
  static init(sequelize) {
    super.init({
    CodMarca: DataTypes.INTEGER,
    Nome: DataTypes.STRING
    }, {
      sequelize,
        freezeTableName: true
    })
  }
  static associate(models) { }
}

module.exports = Marca;
