const { Model, DataTypes } = require('sequelize');

class Recapagem_ColetaItens extends Model {
  static init(sequelize) {
    super.init({
      Cod_Importacao: DataTypes.INTEGER,
      CodEmpresa: DataTypes.INTEGER,
      CodFilial: DataTypes.INTEGER,
      CodVendedorIndex: DataTypes.INTEGER,
      Item: DataTypes.INTEGER,
      CodColeta: DataTypes.INTEGER,
      CodProduto: DataTypes.INTEGER,
      NomeProduto: DataTypes.STRING,
      NumeroSerie: DataTypes.INTEGER,
      CodMarca: DataTypes.INTEGER,
      Marca: DataTypes.STRING,
      Modelo: DataTypes.STRING,
      Dimensao: DataTypes.STRING,
      Desenho: DataTypes.STRING,
      NumeroFogo: DataTypes.STRING,
      NumeroDot: DataTypes.STRING,
      CodSituacao: DataTypes.INTEGER,
      CodTipo: DataTypes.INTEGER,
      Placa: DataTypes.STRING,
      ServicosExecutar: DataTypes.STRING,
      ExameInicial: DataTypes.STRING,
      Valor: DataTypes.DECIMAL(10,2),
      IdMobile: DataTypes.INTEGER,
      ImportaColeta: DataTypes.STRING,
    }, {
      sequelize,
        freezeTableName: true
    })
  }
  static associate(models) {  }
}

module.exports = Recapagem_ColetaItens;

