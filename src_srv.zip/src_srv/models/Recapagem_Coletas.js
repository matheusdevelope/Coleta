const { Model, DataTypes } = require('sequelize');

class Recapagem_Coletas extends Model {
  static init(sequelize) {
    super.init({
      Cod_Importacao: DataTypes.INTEGER,
    CodEmpresa: DataTypes.INTEGER,
    CodFilial: DataTypes.INTEGER,
    CodColeta: DataTypes.INTEGER,
    Item: DataTypes.INTEGER,
    CodVendedorIndex: DataTypes.INTEGER,
    NumeroPedido: DataTypes.STRING,
    NumeroDocumento: DataTypes.STRING,
    NumeroColeta: DataTypes.STRING,
    Status: DataTypes.STRING,
    CodPrioridade: DataTypes.INTEGER,
    DataLancamento: DataTypes.DATE,
    HoraLancamento: DataTypes.STRING,
    UsuarioLancamento: DataTypes.STRING,
    EstacaoLancamentos: DataTypes.STRING,
    DataEmissao: DataTypes.DATE,
    DataColeta: DataTypes.DATE,
    DataPrevistaEntrega: DataTypes.DATE,
    CodVendedor: DataTypes.INTEGER,
    CodColetador: DataTypes.INTEGER,
    CodTecnico: DataTypes.INTEGER,
    CodCliente: DataTypes.INTEGER,
    NomeCliente: DataTypes.STRING,
    CodCancelamento: DataTypes.INTEGER,
    ObservacaoCancelamento: DataTypes.STRING,
    DataCancelamento: DataTypes.DATE,
    HoraCancelamento: DataTypes.TIME,
    UsuarioCancelamento: DataTypes.STRING,
    EstacaoCancelamento: DataTypes.STRING,
    Garantia: DataTypes.STRING,
    ImportaColeta: DataTypes.STRING,
    IdMobile: DataTypes.STRING,
    ItemColeta: DataTypes.STRING

  }, {
    sequelize,
      freezeTableName: true
  })
  }
  static associate(models) { }
}

module.exports = Recapagem_Coletas;

