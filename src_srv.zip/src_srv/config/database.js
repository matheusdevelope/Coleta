module.exports ={
    dialect: 'mssql',
    host: 'sqlserver.cmdlqhlibvmi.sa-east-1.rds.amazonaws.com',
    username:'admin',
    password:'se7e123abc.',
    database:'DBColetas',
    define:{
        timestamps:true
    }
}
/**?
 * 
 module.exports ={
    dialect: 'mssql',
    host: 'localhost',
    username:'admin',
    password:'se7e123abc..',
    database:'BaseTeste',
    define:{
        timestamps:true
    }
}
 * 
 */