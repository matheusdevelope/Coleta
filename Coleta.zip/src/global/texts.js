const GText = {
    title: 'Coletas',
    MyColetas: 'Minhas Coletas',
    SendedColetas: 'Coletas Enviadas',
    NewColeta: 'Nova Coleta',
    Config: 'Configurações',
    Send:'Enviar',
    Cancel:'Cancelar',
    SearchBox:'Nome Cliente',


    IconSearchBox:'search',

}

export default GText