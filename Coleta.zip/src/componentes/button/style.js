import styled from 'styled-components/native'
import Global from '../../global/global'

export const Container = styled.TouchableOpacity`
width: ${Global.widthButtonHeader};
align-items: center;
justify-content: center;
`