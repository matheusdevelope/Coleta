import styled from 'styled-components/native'

export const Line = styled.View`
flex-direction:row;
width: auto;
`
export const Text = styled.TextInput`
`