import styled from 'styled-components/native'
import Global from '../../global/global'

export const Container = styled.SafeAreaView`
`
export const Text = styled.Text`
font-size: ${Global.fontSize};
color: ${Global.blue};
`